import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Taxi Calculator',
      home: TaxiCalculator(),
    );
  }
}

class Taxi {
  String kodeTransaksi;
  String kodePenumpang;
  String namaPenumpang;
  String jenisPenumpang;
  String platNomor;
  String supir;
  double biayaAwal;
  double biayaPerKilometer;
  double jumlahKilometer;
  double totalBayar;

  Taxi({
    required this.kodeTransaksi,
    required this.kodePenumpang,
    required this.namaPenumpang,
    required this.jenisPenumpang,
    required this.platNomor,
    required this.supir,
    required this.biayaAwal,
    required this.biayaPerKilometer,
    required this.jumlahKilometer,
  }) : totalBayar = 0;

  void hitungTotalBayar() {
    double kilometerTerhitung = jumlahKilometer;

    if (jenisPenumpang == "VIP" && jumlahKilometer > 5) {
      kilometerTerhitung -= 5; // Gratis 5 km pertama
    } else if (jenisPenumpang == "GOLD" && jumlahKilometer > 2) {
      kilometerTerhitung -= 2; // Gratis 2 km pertama
    }

    if (kilometerTerhitung < 0) {
      kilometerTerhitung = 0; // Pastikan tidak negatif
    }

    totalBayar = biayaAwal + (biayaPerKilometer * kilometerTerhitung);
  }
}

class TaxiCalculator extends StatefulWidget {
  @override
  _TaxiCalculatorState createState() => _TaxiCalculatorState();
}

class _TaxiCalculatorState extends State<TaxiCalculator> {
  final TextEditingController kilometerController = TextEditingController();
  String result = '';

  void calculateTotal() {
    final double? kilometers = double.tryParse(kilometerController.text);

    if (kilometers == null || kilometers < 0) {
      setState(() {
        result = 'Silakan masukkan jumlah kilometer yang valid.';
      });
      return;
    }

    // Misalnya data ini diisi dari input user
    Taxi taxi = Taxi(
      kodeTransaksi: 'T001',
      kodePenumpang: 'P001',
      namaPenumpang: 'John Doe',
      jenisPenumpang: 'VIP', // Ubah sesuai kebutuhan
      platNomor: 'B 1234 ABC',
      supir: 'Jane Smith',
      biayaAwal: 5000,
      biayaPerKilometer: 2000,
      jumlahKilometer: kilometers,
    );

    taxi.hitungTotalBayar();

    setState(() {
      result = 'Total Bayar: ${taxi.totalBayar.toStringAsFixed(2)}';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Taxi Calculator')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: kilometerController,
              decoration: InputDecoration(labelText: 'Jumlah Kilometer'),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: calculateTotal,
              child: Text('Hitung Total Bayar'),
            ),
            SizedBox(height: 20),
            Text(result, style: TextStyle(fontSize: 20)),
          ],
        ),
      ),
    );
  }
}
