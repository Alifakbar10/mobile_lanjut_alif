package com.example.flutter_uts_2201082009_bb

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
